﻿
#include <iostream>
#include <cassert>
#include <string>
#include <windows.h>
#include <ctime>

using namespace std;
// text, line, source, time.cari vaxti alinmasini internetden arashdirin
class Exception {
public:
	virtual void setTime() {
		time_t now = time(0);//TIMEDE PROBLEM OLA BILER
	
	}

};

class DatabaseException : public Exception {
	public:
		virtual const char* what() const throw() 
		{
			return "Database exception occurred.";
		}
};

class InvalidArgumentException :public Exception {
public:
	virtual const char* what() const throw() {
		return "Invalid argument exception occurred.";
	}
};


class User {
	int _id;
	string _username;
	string _password;
	string _name;
	string _surname;

public:
	User() {
		_id++;
		_username = "Empty";
		_password = "Empty";
		_name = "Empty";
		_surname = "Empty";
	}

	User(string username, string password, string name, string surname) {
		_username = username;
		_password = password;
		_name = name;
		_surname = surname;
	}

	void setUserName(string username) {
		if (_username[0] == tolower(_username[0])) {
			throw invalid_argument("First letter must be capitalized !");
		}
		else
			_username = username;
	}

	string getUserName() { return _username; }

	void setPassword(string password) {
		if (_password.length() < 6) {
			throw invalid_argument("Minimum 7 character!");
		}
		else
			_password = password;
	}

	string getPassword() { return _password; }

	void setName(string name) {
		if (_name.length() < 3) {
			throw invalid_argument("Minimum 4 character!");
		}
		else
			_name = name;
	}

	string getName() { return _name; }

	void setSurName(string surname) {
		if (_surname.length() < 4) {
			throw invalid_argument("Minimum 5 character!");
		}
		else
			_surname = surname;
	}

	string getSurName() { return _surname; }
	int getID() { return _id; }

	void show() const {
		cout << "<== People List ==>" << endl;
		cout << "UserName : " << _username << endl;
		cout << "Name : " << _name << endl;
		cout << "SurName : " << _surname << endl;
		cout << "Password : " << _password<< endl;
	}
};

class Database
{
	User** users;
	int user_count = 0;
public:
	void addUser(const User& user) {
		User** newusers = new User * [user_count + 1];
		for (size_t i = 0; i < user_count; i++)
			newusers[i] = users[i];
		newusers[user_count] = new User(user);
		delete[] users;
		users = newusers;
		user_count++;
	}
	User* getUserByUsername(string username) {
		for (size_t i = 0; i < user_count; i++)
		{
			if (users[i]->getUserName() == username)
				return users[i];
		}
	}
	void updateUser(User& oldUser, const User& newUser) {
		for (size_t i = 0; i < user_count; i++) {
			if (users[i] == &oldUser) {
				delete users[i];

				users[i] = new User(newUser);
				return;
			}
		}
	}
	void deleteUserById(const int& id) {
		size_t i;
		for (i = 0; i < user_count; i++) {
			if (users[i]->getID() == id) {
				delete users[i];
				break;
			}
		}
		if (i == user_count) {
			throw runtime_error("User not found.");
		}
		for (size_t j = i; j < user_count - 1; j++) {
			users[j] = users[j + 1];
		}
		user_count--;
	}
	void hashUserDataById(const int& id){
		size_t i = 0;
		for (size_t i = 0; i < user_count; i++) {
			if (users[i]->getID() == id) {
				return;
			}
		}
	}
	
};



class Registration {
	Database _database;
public:
	Registration(const Database& database) {
		_database = database;
	}
	//eger bu username istifadechi yoxdursa error atsin
	//eger username varsa amma password yanlishdirsa error atsin
	void signIn(string username, string password) 
	{
	   User* user = _database.getUserByUsername(username);
	   if (user == nullptr || user->getPassword() != password) {
		   throw InvalidArgumentException();
	   }
	   else
		   cout << "Correct registration ! " << endl;
	}


	//Eger istifadechi varsa hemen username de throw DatabaseException
	//Eger username xarakter sayi 6 dan kichikdirse InvalidArgumentException
	//Eger username ilk herf kichikdirse InvalidArgumentException
	//Eger password xarakter sayi 6 dan kichikdirse InvalidArgumentException
	//Eger name xarakter sayi 3 dan kichikdirse InvalidArgumentException
	//Eger surname xarakter sayi 4 dan kichikdirse InvalidArgumentException


		void signUp(string username, string password, string name, string surname) {

			if (_database.getUserByUsername(username) != nullptr) {
				throw DatabaseException();
			}
			if (username.length() < 6 || !isupper(username[0])) {
				throw InvalidArgumentException();
			}
			if (password.length() < 6) {
				throw InvalidArgumentException();
			}
			if (name.length() < 3) {
				throw InvalidArgumentException();
			}
			if (surname.length() < 4) {
				throw InvalidArgumentException();
			}

			User user(username, password, name, surname);
			_database.addUser(user);
			cout << "Correct registration !" << endl;
		}
		Database& getDatabase() {
			return _database;
		}
};


class StartUp {
public:
	static void Start() {
		Database db;
		Registration twitter(db);

		User user("Username1", "userPass1", "User1", "UserSurname1");
		twitter.getDatabase().addUser(user);
		user.show();
	}
};


int main() {
	StartUp::Start();

	return 0;
}